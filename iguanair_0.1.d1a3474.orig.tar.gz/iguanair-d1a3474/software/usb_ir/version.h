#ifndef _VERSION_H_
#define _VERSION_H_

/*-----------------------------------------------------------------------------------
Version strings as defined by git and release.h. The version.h file is created
from version.h.in. To update the release, update version.h.in. BEWARE: all changes
to version.h are discarded by runCmake.
-----------------------------------------------------------------------------------*/
#ifdef _DEBUG
#define IGUANAIR_VER_STR(a) "DEBUG!: mk@snorken"
#else
#define IGUANAIR_VER_STR(a) "Release: 1.1.2 - 2d7afb6:M-2017-02-05 13:27:39 +0100"
#endif

#endif
